Applicatoin Documentation 

About the app 

This  is a basic warehouse application. It allows users to read, create, delete and update exicting products. 

Local Setup and Dependencies

To run the application locally, follow the step-by-step instructions below: 

1. Clone the repository from GitHub:
git clone https://github.com/azizaslam/webtechnology 
2. Navigate to the project directory:
cd webtechnology
3. Install the application dependencies using npm: 
npm iexpress pug 
4. Start the application:
 node app

This command will start the application and make it accessible at 'https://github.com/azizaslam/webtechnology'
